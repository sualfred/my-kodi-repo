# fTV Mosaic Screensaver
This screensaver imitates the Mosaic Screensaver of FireTV devices.
Support for movie/TV show artworks or a custom image folder.



